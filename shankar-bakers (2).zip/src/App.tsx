import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import CakeGallery from "./components/CakeGallery";
import Menu from "./components/Menu";
import Reviews from "./components/Reviews";
import SocialFeed from "./components/SocialFeed";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  const handleScrollToSegment = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between selection:bg-brand-pink/30 selection:text-white">
      {/* 1. Transparent Sticky Navbar */}
      <Navbar onContactClick={() => handleScrollToSegment("contact")} />

      {/* Main page items */}
      <main className="flex-1 w-full flex flex-col">
        {/* 2. Full-Screen Visual Hero Section */}
        <Hero
          onViewCakesClick={() => handleScrollToSegment("gallery")}
          onContactClick={() => handleScrollToSegment("contact")}
        />

        {/* 3. About Shankar Bakers Section */}
        <About />

        {/* 4. Complete Cake Gallery (40 photos filterable with Lightbox) */}
        <CakeGallery />

        {/* 5. Full Cake Gourmet Menu Section */}
        <Menu />

        {/* 6. Google Auto Sliding Testimonials */}
        <Reviews />

        {/* 7. Instagram social media feed and badges */}
        <SocialFeed />

        {/* 8. Contact Details Cards & Custom Inquiry Form */}
        <Contact />
      </main>

      {/* 9. Elegant Branding Dark Footer */}
      <Footer />
    </div>
  );
}
