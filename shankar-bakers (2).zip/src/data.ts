export interface CakeGalleryItem {
  id: string;
  name: string;
  category: "Birthday Cakes" | "Wedding Cakes" | "Chocolate Cakes" | "Anniversary Cakes" | "Designer Cakes";
  imageUrl: string;
  description: string;
  sku: string;
}

export interface MenuItem {
  id: string;
  name: string;
  category: "Chocolate Cakes" | "Vanilla Cakes" | "Fruit Cakes" | "Designer Cakes" | "Cupcakes";
  price: number;
  description: string;
  imageUrl: string;
  badge?: "Best Seller" | "Chef Special" | "New Arrival" | "Eggless";
  rating: number;
}

export interface Review {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  rating: number;
  text: string;
  date: string;
}

export interface InstagramPost {
  id: string;
  imageUrl: string;
  likes: number;
  comments: number;
  caption: string;
}

export const GALLERY_CAKES: CakeGalleryItem[] = [
  // Chocolate Cakes
  {
    id: "gal-c1",
    name: "Midnight Chocolate Truffle",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068051494.jpg",
    description: "Layers of moist Belgian cocoa sponge smothered in rich, dark chocolate ganache and golden luster dust.",
    sku: "SB-CHOC-01"
  },
  {
    id: "gal-c2",
    name: "Double Fudge Mountain",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069182660.jpg",
    description: "Triple-chocolate velvet cake with dense homemade fudge layers and gourmet dark chocolate shavings.",
    sku: "SB-CHOC-02"
  },
  {
    id: "gal-c3",
    name: "Sinfonier Lava Gateau",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069184728.jpg",
    description: "Elegant chocolate drip masterpiece accented with gold dust, molten core details, and organic berries.",
    sku: "SB-CHOC-03"
  },
  {
    id: "gal-c4",
    name: "Velvet Chocolate Mousse",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069595244.jpg",
    description: "An incredibly smooth chocolate mousse sponge surrounded by dark chocolate ribbons and organic cherry fillings.",
    sku: "SB-CHOC-04"
  },
  {
    id: "gal-c5",
    name: "Hazelnut Praline Dream",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069188089.jpg",
    description: "Luxurious hazelnut cream and dark chocolate glaze adorned with toasted Piedmont hazelnuts.",
    sku: "SB-CHOC-05"
  },
  {
    id: "gal-c6",
    name: "Black Forest Empress",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069190331.jpg",
    description: "Traditional German sponge soaked with top-shelf cherry liqueur, sweet black cherries, and chantilly cream.",
    sku: "SB-CHOC-06"
  },
  {
    id: "gal-c7",
    name: "Espresso Praline Torte",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069192258.jpg",
    description: "Rich espresso infused dark sponge with coffee bean curls and smooth whipped coffee-fudge icing.",
    sku: "SB-CHOC-07"
  },
  {
    id: "gal-c8",
    name: "Salted Caramel Obsidian",
    category: "Chocolate Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068053863.jpg",
    description: "Salty-sweet paradise with a dense dark forest base layered with thick liquid gold caramel.",
    sku: "SB-CHOC-08"
  },

  // Birthday Cakes
  {
    id: "gal-b1",
    name: "Rosette Celebration Spark",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069194084.jpg",
    description: "A gorgeous pastel rose buttered sponge decorated with premium buttercream roses and pearl beads.",
    sku: "SB-BDAY-01"
  },
  {
    id: "gal-b2",
    name: "Confetti Carnival Cake",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069196087.jpg",
    description: "Classic vanilla funfetti cake layers embedded with rich rainbow sprinkles and dynamic sugar frosting.",
    sku: "SB-BDAY-02"
  },
  {
    id: "gal-b3",
    name: "Summer Berry Cascading",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068056100.jpg",
    description: "Soft vanilla sponge topped with glazed raspberries, organic strawberries and beautiful edible pansies.",
    sku: "SB-BDAY-03"
  },
  {
    id: "gal-b4",
    name: "Princess Rose Macaron",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068058359.jpg",
    description: "Majestic pastel pink drip cake crown adorned with raspberry macarons and handmade white chocolate gems.",
    sku: "SB-BDAY-04"
  },
  {
    id: "gal-b5",
    name: "Blueberry Bliss Burst",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069197844.jpg",
    description: "Gourmet wild blueberry sponge loaded with thick berry compote and delicate lavender-cream accents.",
    sku: "SB-BDAY-05"
  },
  {
    id: "gal-b6",
    name: "Pastel Ribbon Delight",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069199296.jpg",
    description: "Symmetrical piping details with elegant butter icing swirl paths and a soft golden calligraphy card slot.",
    sku: "SB-BDAY-06"
  },
  {
    id: "gal-b7",
    name: "Lemon Raspberry Drizzle",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069201039.jpg",
    description: "Tangy curd lemon cake paired with transient fresh raspberries and whipped organic vanilla bean frosting.",
    sku: "SB-BDAY-07"
  },
  {
    id: "gal-b8",
    name: "Golden Crown Velvet",
    category: "Birthday Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068061361.jpg",
    description: "Regal black-painted red velvet cake with an actual miniature edible golden royal crown topper.",
    sku: "SB-BDAY-08"
  },

  // Wedding Cakes
  {
    id: "gal-w1",
    name: "Renaissance Flora Cascade",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069202963.jpg",
    description: "Three-tier magnificent masterpiece featuring delicate, hand-sculpted sugar flowers and vintage cream lace.",
    sku: "SB-WEDD-01"
  },
  {
    id: "gal-w2",
    name: "Classic Ivory Tower",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069205057.jpg",
    description: "Regal 4-tiered wedding torte with pure premium white chocolate ganache layers and structural clean piping.",
    sku: "SB-WEDD-02"
  },
  {
    id: "gal-w3",
    name: "Golden Hour Botanical",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069206972.jpg",
    description: "Stately 3-tier rustic semi-naked cake dressed in eucalyptus leaves, fresh figs and real gold leaf.",
    sku: "SB-WEDD-03"
  },
  {
    id: "gal-w4",
    name: "Symphony of Pearls",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069597720.jpg",
    description: "Pure white textured fondant wedding cake with thousands of glistening edible micro-sugar pearls.",
    sku: "SB-WEDD-04"
  },
  {
    id: "gal-w5",
    name: "Rose Quartz Romance",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069209048.jpg",
    description: "Blush-hued watercolor fondant cake reflecting real polished quartzite patterns with edible pink quartz crystals.",
    sku: "SB-WEDD-05"
  },
  {
    id: "gal-w6",
    name: "Emerald Guild Luxe",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069211120.jpg",
    description: "A deep forest green velvet wedding torte bordered with custom hand-carved golden sugar rings.",
    sku: "SB-WEDD-06"
  },
  {
    id: "gal-w7",
    name: "Cascading Orchid Tier",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069213524.jpg",
    description: "Draped in majestic white and soft pink orchids, a beautiful modern square-on-round geometric tier stack.",
    sku: "SB-WEDD-07"
  },
  {
    id: "gal-w8",
    name: "Minimalist Whisper",
    category: "Wedding Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069215286.jpg",
    description: "Sleek and tall single tier extra height vanilla bean cake with a single hand-painted sugar plum blossom.",
    sku: "SB-WEDD-08"
  },

  // Anniversary Cakes
  {
    id: "gal-a1",
    name: "Silver Jubilee Crest",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069216930.jpg",
    description: "Beautiful silver metallic drip design over dark charcoal chocolate cream base filled with rum-macerated plums.",
    sku: "SB-ANIV-01"
  },
  {
    id: "gal-a2",
    name: "Golden Splendor Rose",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069218495.jpg",
    description: "Delicate cream textured torte displaying 24K edible gold flakes and dark crimson everlasting sugar roses.",
    sku: "SB-ANIV-02"
  },
  {
    id: "gal-a3",
    name: "Hearts Interlocked",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069220297.jpg",
    description: "Twin-heart shaped red velvet creations side-by-side with creamy white chocolate premium filling.",
    sku: "SB-ANIV-03"
  },
  {
    id: "gal-a4",
    name: "Everlasting Sunset Pastel",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069222304.jpg",
    description: "A gorgeous sunset-gradient cake adorned with gold leaf brushwork and dehydrated sugar crystals.",
    sku: "SB-ANIV-04"
  },
  {
    id: "gal-a5",
    name: "Vintage Monogram Torte",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068064145.jpg",
    description: "Victorian-styled lambeth piping featuring highly intricate scrolls, shell borders, and customized initials.",
    sku: "SB-ANIV-05"
  },
  {
    id: "gal-a6",
    name: "Crimson Velvet Knot",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068066196.jpg",
    description: "Rich moist velvet sponge layered with smooth premium cream cheese, topped with hand-crafted ribbon motifs.",
    sku: "SB-ANIV-06"
  },
  {
    id: "gal-a7",
    name: "Opulent Macaron Ring",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069225047.jpg",
    description: "A gorgeous circular ring cake baked with organic almond flour and topped with fresh rose macarons.",
    sku: "SB-ANIV-07"
  },
  {
    id: "gal-a8",
    name: "Vanilla Orchid Dream",
    category: "Anniversary Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069226795.jpg",
    description: "Decadent Madagascan vanilla bean butter torte surrounded by gorgeous white sugar floral arrangements.",
    sku: "SB-ANIV-08"
  },

  // Designer Cakes
  {
    id: "gal-d1",
    name: "Celestial Geode Masterpiece",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069228604.jpg",
    description: "A stunning hand-carved cake mimicking an amethyst geode with real translucent sugar rock crystals and purple hues.",
    sku: "SB-DESG-01"
  },
  {
    id: "gal-d2",
    name: "Avante-Garde Pastel Brushstroke",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068068594.jpg",
    description: "Crisp white chocolate sails tinted in rose, lavender, and copper rising from a fault-line style cake base.",
    sku: "SB-DESG-02"
  },
  {
    id: "gal-d3",
    name: "The Sculptured Monarch",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069230092.jpg",
    description: "Vibrant abstract buttercream modeling replicating oil-paint strokes topped with realistic edible wafer paper butterflies.",
    sku: "SB-DESG-03"
  },
  {
    id: "gal-d4",
    name: "Baroque Gilded Charcoal",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068070495.jpg",
    description: "Stunning stark black chocolate glaze embellished with hand-carved baroque edible gold frames.",
    sku: "SB-DESG-04"
  },
  {
    id: "gal-d5",
    name: "Watercolor Blossom Column",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069235478.jpg",
    description: "Hand-painted edible watercolor flower canvas stretching around a perfectly structured high-column cake.",
    sku: "SB-DESG-05"
  },
  {
    id: "gal-d6",
    name: "Terrazzo Geometric Cube",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069233691.jpg",
    description: "Ultra-modern cubed cake featuring custom-dyed chocolate shards resembling luxury terrazzo floors.",
    sku: "SB-DESG-06"
  },
  {
    id: "gal-d7",
    name: "Spherical Cosmic Orb",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780069232083.jpg",
    description: "Floating white chocolate shell structure airbrushed with nebula stars and gold leaf swirls.",
    sku: "SB-DESG-07"
  },
  {
    id: "gal-d8",
    name: "Chantilly Lace Cascade",
    category: "Designer Cakes",
    imageUrl: "/src/assets/images/regenerated_image_1780068073281.jpg",
    description: "A gorgeous ivory columns structured designer cake with stunning sugar-crafted Victorian veil draperies.",
    sku: "SB-DESG-08"
  }
];

export const MENU_CAKES: MenuItem[] = [
  // Chocolate Cakes
  {
    id: "menu-1",
    name: "Premium Belgian Truffle",
    category: "Chocolate Cakes",
    price: 1199,
    description: "Premium chocolate sponge filled with rich layers of authentic imported bittersweet Belgian chocolate truffle cream.",
    imageUrl: "/src/assets/images/regenerated_image_1780068076066.jpg",
    badge: "Best Seller",
    rating: 4.9
  },
  {
    id: "menu-2",
    name: "Hazelnut Ferrero Crunch",
    category: "Chocolate Cakes",
    price: 1399,
    description: "A gorgeous chocolate hazelnut sponge filled with roasted hazelnuts, wafer crumbs, and smooth Ferrero spread.",
    imageUrl: "/src/assets/images/regenerated_image_1780069237595.jpg",
    badge: "Chef Special",
    rating: 5.0
  },
  {
    id: "menu-3",
    name: "Dark Forest Cherry",
    category: "Chocolate Cakes",
    price: 999,
    description: "Classic black forest elements, loaded with brandied syrup, rich heavy whipping cream, and tart dark cherries.",
    imageUrl: "/src/assets/images/regenerated_image_1780069239506.jpg",
    badge: "Eggless",
    rating: 4.8
  },
  {
    id: "menu-4",
    name: "Salted Caramel Volcano",
    category: "Chocolate Cakes",
    price: 1249,
    description: "Soft cocoa sponge topped with a bubbling fountain of homemade salted caramel and fleur de sel.",
    imageUrl: "/src/assets/images/regenerated_image_1780068078642.jpg",
    rating: 4.7
  },

  // Vanilla Cakes
  {
    id: "menu-5",
    name: "Classic Madagascar Vanilla",
    category: "Vanilla Cakes",
    price: 899,
    description: "A buttery white sponge infused with authentic, scraped Madagascar vanilla bean caviar and silk butter frosting.",
    imageUrl: "/src/assets/images/regenerated_image_1780069241335.jpg",
    badge: "Eggless",
    rating: 4.6
  },
  {
    id: "menu-6",
    name: "White Chocolate Almond Torte",
    category: "Vanilla Cakes",
    price: 1149,
    description: "Creamy white chocolate cream matched with slivered roasted almonds and sweet almond marzipan base.",
    imageUrl: "/src/assets/images/regenerated_image_1780068081492.jpg",
    badge: "New Arrival",
    rating: 4.8
  },
  {
    id: "menu-7",
    name: "Caramel Macchiato Velvet",
    category: "Vanilla Cakes",
    price: 1099,
    description: "Espresso cake layers bathed in caramel sauce, covered in a luscious, light buttercream.",
    imageUrl: "/src/assets/images/regenerated_image_1780069243183.jpg",
    rating: 4.7
  },

  // Fruit Cakes
  {
    id: "menu-8",
    name: "Alphonso Mango Sunshine",
    category: "Fruit Cakes",
    price: 1299,
    description: "Seasonal bliss layered with fresh chopped Alphonso mango pulp, chiffon sponge, and light whipped cream.",
    imageUrl: "/src/assets/images/regenerated_image_1780069245144.jpg",
    badge: "Best Seller",
    rating: 4.9
  },
  {
    id: "menu-9",
    name: "Mixed Berry Chantilly",
    category: "Fruit Cakes",
    price: 1349,
    description: "Moist yellow cake packed with fresh strawberries, blueberries, and raspberries under light chantilly.",
    imageUrl: "/src/assets/images/regenerated_image_1780068084746.jpg",
    rating: 4.9
  },
  {
    id: "menu-10",
    name: "Tropical Pineapple Glazed",
    category: "Fruit Cakes",
    price: 849,
    description: "Spongy base layers highlighting syrupy sweet caramelized pineapples and glossy sweet cherry accents.",
    imageUrl: "/src/assets/images/regenerated_image_1780069246892.jpg",
    badge: "Eggless",
    rating: 4.5
  },
  {
    id: "menu-11",
    name: "Lemon Raspberry Cloud",
    category: "Fruit Cakes",
    price: 1199,
    description: "Freshly squeezed lemon curd layers paired with homemade raspberry reduction and cream icing.",
    imageUrl: "/src/assets/images/regenerated_image_1780069248885.jpg",
    badge: "Chef Special",
    rating: 4.8
  },

  // Designer Cakes
  {
    id: "menu-12",
    name: "Royal Geode Cake",
    category: "Designer Cakes",
    price: 2499,
    description: "Stunning designer creation displaying custom rock sugar crystals resembling a radiant emerald geode cavity.",
    imageUrl: "/src/assets/images/regenerated_image_1780068093029.jpg",
    badge: "Chef Special",
    rating: 5.0
  },
  {
    id: "menu-13",
    name: "Pastel Drip & Macarons",
    category: "Designer Cakes",
    price: 1899,
    description: "Extravagant pastel coloring, featuring professional drip icing, luxury macarons, and custom sprinkles.",
    imageUrl: "/src/assets/images/regenerated_image_1780068098260.jpg",
    badge: "Best Seller",
    rating: 4.9
  },
  {
    id: "menu-14",
    name: "Abstract Buttercream Paint",
    category: "Designer Cakes",
    price: 1699,
    description: "An artistic cake with hand-painted textured palette knife colored strokes and glowing gold-leaf accents.",
    imageUrl: "/src/assets/images/regenerated_image_1780068102006.jpg",
    badge: "New Arrival",
    rating: 4.8
  },
  {
    id: "menu-15",
    name: "Gilded Obsidian Black",
    category: "Designer Cakes",
    price: 2199,
    description: "Deep charcoal chocolate fudge cake decorated with baroque 24k edible gold dust frames and patterns.",
    imageUrl: "/src/assets/images/regenerated_image_1780068107346.jpg",
    rating: 5.0
  },

  // Cupcakes
  {
    id: "menu-16",
    name: "Red Velvet Rosette Cupcake",
    category: "Cupcakes",
    price: 149,
    description: "Moist red velvet cupcake base finished with a beautiful, tall cream cheese rosette swirl.",
    imageUrl: "/src/assets/images/regenerated_image_1780068111454.jpg",
    badge: "Best Seller",
    rating: 4.9
  },
  {
    id: "menu-17",
    name: "Double Chocolate Lava Mini",
    category: "Cupcakes",
    price: 159,
    description: "A chocoholic's heaven with a dense chocolate crumb base and a hidden molten fudge interior core.",
    imageUrl: "/src/assets/images/regenerated_image_1780068115786.jpg",
    rating: 4.8
  },
  {
    id: "menu-18",
    name: "Pink Champagne Berry",
    category: "Cupcakes",
    price: 179,
    description: "Sparkling grape reduction infused sponge topped with organic strawberry buttercream and silver beads.",
    imageUrl: "/src/assets/images/regenerated_image_1780068119459.jpg",
    badge: "New Arrival",
    rating: 5.0
  },
  {
    id: "menu-19",
    name: "Matcha White Velvet Cupcake",
    category: "Cupcakes",
    price: 169,
    description: "Matcha organic green tea cupcake topped with soft whipped white chocolate ganache and green tea dust.",
    imageUrl: "/src/assets/images/regenerated_image_1780068124145.jpg",
    badge: "Chef Special",
    rating: 4.9
  }
];

export const REVIEWS: Review[] = [
  {
    id: "rev-1",
    name: "Aarav Sharma",
    role: "Local Guide",
    avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&auto=format&fit=crop&q=85",
    rating: 5,
    text: "Best cake shop in Siliguri. Amazing taste and design! I ordered their Midnight Chocolate Truffle for my wedding anniversary and every guest was absolutely blown away. Highly recommended!",
    date: "1 week ago"
  },
  {
    id: "rev-2",
    name: "Priya Mukherjee",
    role: "Verified Customer",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=85",
    rating: 5,
    text: "Beautiful custom cakes and very friendly service. The designer geode cake was exactly how I pictured it. The pastel colors, edible crystals, and incredible taste were unmatched.",
    date: "3 days ago"
  },
  {
    id: "rev-3",
    name: "Rohan Das",
    role: "Food Blogger",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=85",
    rating: 5,
    text: "Cake quality is premium and delivery is fast. Their Ferrero crunch cake is something to die for. Shankar Bakers are the absolute royalty when it comes to desserts in West Bengal!",
    date: "2 weeks ago"
  },
  {
    id: "rev-4",
    name: "Ananya Sen",
    role: "Regular Customer",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&auto=format&fit=crop&q=85",
    rating: 5,
    text: "My absolute go-to place for birthdays. Their cupcakes are magical, and the vanilla bean cakes represent class and deliciousness. Super hygienic packaging as well!",
    date: "4 days ago"
  }
];

export const INSTAGRAM_POSTS: InstagramPost[] = [
  {
    id: "ig-1",
    imageUrl: "/src/assets/images/regenerated_image_1780068128469.jpg",
    likes: 843,
    comments: 42,
    caption: "The ultimate Royal Belgian Truffle cake, handcrafted with imported gold-leaf flakes. Rich. Pure. Indulgent. ✨ #ShankarBakers #SiliguriFood #ModernGourmet"
  },
  {
    id: "ig-2",
    imageUrl: "/src/assets/images/regenerated_image_1780068132700.jpg",
    likes: 1205,
    comments: 67,
    caption: "Birthday roses and edible pearls! Making your sweet moments beautiful, one tier at a time. 🌸 Order your custom birthday creation via the link in bio. #CakesInSiliguri"
  },
  {
    id: "ig-3",
    imageUrl: "/src/assets/images/regenerated_image_1780068136088.jpg",
    likes: 954,
    comments: 31,
    caption: "Four tiers of pure buttercream luxury for Sneha & Rohan's special day. Best wishes to the couple from team Shankar Bakers. 💍🥂 #WeddingCakes #SiliguriWeddings"
  },
  {
    id: "ig-4",
    imageUrl: "/src/assets/images/regenerated_image_1780068139788.jpg",
    likes: 712,
    comments: 25,
    caption: "Bite-sized magic! Our red velvet and whipped rose-cream cupcakes are baking fresh every hour. Pop in today for a quick bliss. 🧁💖 #SweetTreats #SiliguriBakery"
  },
  {
    id: "ig-5",
    imageUrl: "/src/assets/images/regenerated_image_1780068143378.jpg",
    likes: 1120,
    comments: 89,
    caption: "Creative fluid brushstrokes! Designing custom cakes that are as artistic as they are mouthwatering. What is your dream design? Let us bake it! 🎨🎂 #ArtisanCake"
  },
  {
    id: "ig-6",
    imageUrl: "/src/assets/images/regenerated_image_1780068148174.jpg",
    likes: 624,
    comments: 18,
    caption: "Freshly harvested summer berries paired with a light, airy chiffon sponge. Taste the sunshine! 🍓🫐🌞 #FruitCakes #ShankarBakersSiliguri"
  }
];
