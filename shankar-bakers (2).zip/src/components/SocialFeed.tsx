import { INSTAGRAM_POSTS } from "../data";
import { Instagram, MessageCircle, Heart, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export default function SocialFeed() {
  return (
    <section id="social" className="py-24 px-6 relative bg-zinc-950/40">
      <div className="max-w-7xl mx-auto">
        
        {/* Social Header details */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div className="text-left">
            <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
              STAY CONNECTED WITH US
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-2">
              Join Our Sweet Community
            </h2>
            <p className="text-xs sm:text-sm text-cream-200/80">
              Get behind-the-scenes bakery action, sweet recipe secrets, and priority announcements!
            </p>
          </div>

          {/* Core Follow Button Badge */}
          <div className="flex flex-wrap items-center gap-4">
            <div className="text-left md:text-right hidden sm:block">
              <p className="font-serif font-bold text-white text-lg">@shankar_bakers</p>
              <p className="text-[10px] font-mono text-zinc-400">12.4K Follower • 640 Posts</p>
            </div>
            
            <a
              id="instagram-follow-btn"
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-full bg-linear-to-r from-purple-600 via-pink-600 to-amber-500 text-white font-bold text-xs uppercase tracking-widest transition-transform hover:scale-105 duration-300 flex items-center gap-2 shadow-lg cursor-pointer"
            >
              <Instagram className="w-4 h-4" />
              <span>Follow on Instagram</span>
            </a>
          </div>
        </div>

        {/* 4-Photo Premium Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
          {INSTAGRAM_POSTS.filter(post => post.id !== "ig-2" && post.id !== "ig-3").map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="group relative rounded-2xl overflow-hidden aspect-square bg-zinc-900 border border-white/5 cursor-pointer shadow-lg"
            >
              <img
                src={post.imageUrl}
                alt={`Instagram Post by Shankar Bakers`}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
                loading="lazy"
              />

              {/* High-Contrast Interactive Overlay */}
              <div className="absolute inset-0 bg-black/80 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-all duration-300 p-4 flex flex-col justify-between">
                
                {/* Stats Row */}
                <div className="flex items-center gap-4 text-white font-mono text-xs mt-2">
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4 text-brand-pink fill-current" />
                    <span>{post.likes}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4 text-gold fill-current" />
                    <span>{post.comments}</span>
                  </div>
                </div>

                {/* Caption snippet */}
                <p className="text-[11px] text-cream-150/90 leading-relaxed line-clamp-4 font-sans text-left pb-2">
                  {post.caption}
                </p>

              </div>
            </motion.div>
          ))}
        </div>

        {/* Multi-Channel Interactive Social Links */}
        <div className="p-8 rounded-3xl bg-dark-card border border-white/5 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-10 max-w-5xl mx-auto">
          
          <div className="text-left md:max-w-md">
            <h4 className="font-serif font-bold text-xl text-white mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-brand-pink" />
              We Are Active Everywhere
            </h4>
            <p className="text-xs text-cream-205/70 leading-relaxed">
              Reach out directly, browse daily menu announcements on Facebook or place orders via direct WhatsApp messaging channels. We reply instantaneously!
            </p>
          </div>

          {/* Social Channels Icons Row wrapper */}
          <div className="flex flex-wrap items-center gap-6 justify-center">
            
            <a
              id="social-wa-badge"
              href="https://wa.me/918016234702"
              target="_blank"
              rel="noopener noreferrer"
              className="px-5 py-3 rounded-xl bg-zinc-950 hover:bg-zinc-900 border border-zinc-900 hover:border-emerald-500/30 flex items-center gap-3 group transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="w-9 h-9 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div className="text-left font-sans">
                <p className="text-[9px] font-mono text-zinc-400 uppercase tracking-widest">WhatsApp Direct</p>
                <p className="text-xs font-bold text-white">08016 234702</p>
              </div>
            </a>

          </div>

        </div>

      </div>
    </section>
  );
}
