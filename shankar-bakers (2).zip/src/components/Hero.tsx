import { motion } from "motion/react";
import { Sparkles, ArrowRight, Heart, Star, Cake } from "lucide-react";

interface HeroProps {
  onViewCakesClick: () => void;
  onContactClick: () => void;
}

export default function Hero({ onViewCakesClick, onContactClick }: HeroProps) {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-28 pb-16 px-6 overflow-hidden bg-radial from-zinc-950 via-zinc-950 to-[#050507]"
    >
      {/* Absolute Luxurious Visual Background Overlay & Glows */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1519340241574-2bec64d0094b?w=1920&auto=format&fit=crop&q=90"
          alt="Premium Luxury Cakes Background"
          className="w-full. h-full w-full object-cover object-center opacity-25 filter brightness-[0.7] scale-105"
          referrerPolicy="no-referrer"
        />
        {/* Soft elegant color ambient glows */}
        <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[350px] md:w-[600px] h-[350px] md:h-[600px] rounded-full bg-brand-pink/10 blur-[80px] md:blur-[140px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[300px] md:w-[500px] h-[300px] md:h-[500px] rounded-full bg-gold/5 blur-[80px] md:blur-[140px] pointer-events-none" />
        
        {/* Black gradient masking */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#09090b] via-[#09090b]/80 to-[#09090b]/60" />
      </div>

      {/* Floating elegant pastry outline vectors / micro decoration */}
      <div className="absolute inset-0 z-10 pointer-events-none hidden lg:block">
        <motion.div
          animate={{ y: [0, -15, 0], rotate: [0, 5, 0] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-12 w-12 h-12 bg-zinc-900/30 border border-brand-pink/10 rounded-full flex items-center justify-center shadow-lg backdrop-blur-xs text-brand-pink/40"
        >
          <Cake className="w-6 h-6" />
        </motion.div>
        
        <motion.div
          animate={{ y: [0, 20, 0], rotate: [0, -8, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-1/3 right-16 w-14 h-14 bg-zinc-900/30 border border-gold/15 rounded-full flex items-center justify-center shadow-lg backdrop-blur-xs text-gold/30"
        >
          <Sparkles className="w-6 h-6" />
        </motion.div>

        <motion.div
          animate={{ y: [0, -10, 0], scale: [1, 1.05, 1] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/3 right-1/4 w-10 h-10 bg-zinc-900/10 border border-brand-pink/5 rounded-full flex items-center justify-center text-brand-pink/20"
        >
          <Heart className="w-5 h-5 fill-current" />
        </motion.div>
      </div>

      {/* Hero Content Container */}
      <div className="relative z-20 max-w-5xl mx-auto text-center flex flex-col items-center">
        {/* Sparkle Tag */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-pink/10 border border-brand-pink/20 text-brand-pink text-xs uppercase tracking-widest font-mono font-medium mb-8 shadow-xs"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Artisan Pastry & Designer Cakes Siliguri</span>
        </motion.div>

        {/* Master Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-serif text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight text-white leading-[1.1] mb-6 max-w-4xl"
        >
          Fresh Cakes Made <br className="hidden sm:inline" />
          With Love <span className="text-brand-pink inline-block animate-pulse">❤️</span>
        </motion.h1>

        {/* Brand Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-cream-200 text-sm sm:text-base md:text-xl font-medium tracking-wide max-w-2xl mb-12"
        >
          Custom Cakes <span className="text-brand-pink/50 mx-2">•</span> 
          Birthday Cakes <span className="text-brand-pink/50 mx-2">•</span> 
          Wedding Cakes <span className="text-brand-pink/50 mx-2">•</span> 
          Designer Cakes
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 sm:gap-6 w-full max-w-sm sm:max-w-none items-center justify-center mb-16"
        >
          <button
            id="hero-view-cakes-btn"
            onClick={onViewCakesClick}
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-brand-pink text-dark-obsidian hover:bg-brand-pink-light tracking-wide font-bold text-sm cursor-pointer transition-all duration-300 flex items-center justify-center gap-2 border border-brand-pink glow-pink-hover shadow-lg shadow-brand-pink/15"
          >
            <span>View Cakes</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          
          <button
            id="hero-contact-btn"
            onClick={onContactClick}
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-transparent text-cream-100 hover:text-dark-obsidian hover:bg-cream-100 border border-cream-300 font-bold tracking-wide text-sm cursor-pointer transition-all duration-300 flex items-center justify-center gap-2"
          >
            <span>Contact Us</span>
          </button>
        </motion.div>

        {/* Feature quick badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 w-full max-w-4xl pt-8 border-t border-brand-pink/5"
        >
          <div className="flex items-center gap-3 justify-center md:justify-start">
            <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-brand-pink/10 flex items-center justify-center text-brand-pink">
              <Star className="w-5 h-5 fill-current" />
            </div>
            <div className="text-left">
              <p className="font-serif font-bold text-sm lg:text-lg text-white">4.9/5 Star</p>
              <p className="text-[10px] text-cream-300/60 uppercase tracking-widest font-mono">Google Reviews</p>
            </div>
          </div>

          <div className="flex items-center gap-3 justify-center">
            <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-gold/10 flex items-center justify-center text-gold">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div className="text-left">
              <p className="font-serif font-bold text-sm lg:text-lg text-white">100% Pure</p>
              <p className="text-[10px] text-cream-300/60 uppercase tracking-widest font-mono">Hygienic & Fresh</p>
            </div>
          </div>

          <div className="flex items-center gap-3 justify-center">
            <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-brand-pink/10 flex items-center justify-center text-brand-pink">
              <Cake className="w-5 h-5" />
            </div>
            <div className="text-left">
              <p className="font-serif font-bold text-sm lg:text-lg text-white">Bespoke</p>
              <p className="text-[10px] text-cream-300/60 uppercase tracking-widest font-mono">Custom Artisan Designs</p>
            </div>
          </div>

          <div className="flex items-center gap-3 justify-center md:justify-end">
            <div className="w-10 h-10 rounded-xl bg-zinc-950 border border-gold/10 flex items-center justify-center text-gold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="text-left">
              <p className="font-serif font-bold text-sm lg:text-lg text-white">Fast Delivery</p>
              <p className="text-[10px] text-cream-300/60 uppercase tracking-widest font-mono">Guaranteed Safe</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Curve boundary divider at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-16 w-full bg-gradient-to-t from-[#09090b] to-transparent pointer-events-none" />
    </section>
  );
}
