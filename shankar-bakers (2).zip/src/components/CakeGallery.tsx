import { useState, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { GALLERY_CAKES, CakeGalleryItem } from "../data";
import { Maximize2, X, ChevronLeft, ChevronRight, MessageCircle, Sparkles, Copy, Check } from "lucide-react";

export default function CakeGallery() {
  const [activeCategory, setActiveCategory] = useState<string>("All Cakes");
  const [selectedItem, setSelectedItem] = useState<CakeGalleryItem | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const categories = [
    "All Cakes",
    "Birthday Cakes",
    "Wedding Cakes",
    "Chocolate Cakes",
    "Anniversary Cakes",
    "Designer Cakes",
  ];

  // Filter 40 cakes dynamically
  const filteredCakes = activeCategory === "All Cakes"
    ? GALLERY_CAKES
    : GALLERY_CAKES.filter((cake) => cake.category === activeCategory);

  const handleCopySKU = (sku: string) => {
    navigator.clipboard.writeText(sku);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleNextItem = (currentId: string) => {
    const currentIndex = filteredCakes.findIndex((item) => item.id === currentId);
    if (currentIndex < filteredCakes.length - 1) {
      setSelectedItem(filteredCakes[currentIndex + 1]);
    } else {
      setSelectedItem(filteredCakes[0]); // Wrap around
    }
  };

  const handlePrevItem = (currentId: string) => {
    const currentIndex = filteredCakes.findIndex((item) => item.id === currentId);
    if (currentIndex > 0) {
      setSelectedItem(filteredCakes[currentIndex - 1]);
    } else {
      setSelectedItem(filteredCakes[filteredCakes.length - 1]); // Wrap around
    }
  };

  return (
    <section id="gallery" className="py-24 px-6 relative bg-dark-obsidian">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-brand-pink/5 blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        
        {/* Header Title Grid */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
            SHANKAR BAKERS COLLECTION
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-6">
            Elite Cake Gallery
          </h2>
          <p className="text-sm md:text-base text-cream-200/80 leading-relaxed">
            Browse through our luxury selection of 40 custom cakes. Each creation represents our signature commitment to moist textures, premium organic layers, and bespoke styling.
          </p>
        </div>

        {/* Filter Categories Tabs Navigation */}
        <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 sm:px-6 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300 pointer-events-auto cursor-pointer focus:outline-none ${
                activeCategory === cat
                  ? "bg-brand-pink text-dark-obsidian font-bold shadow-md shadow-brand-pink/20"
                  : "bg-dark-card border border-white/5 text-cream-300 hover:text-brand-pink hover:border-brand-pink/30 hover:bg-zinc-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Dynamic Masonry-like Grid layout for 40 Cake Photos */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredCakes.map((cake, index) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={cake.id}
                id={`gallery-item-${cake.id}`}
                className="group relative rounded-2xl overflow-hidden bg-dark-card border border-white/5 glow-pink-hover h-[320px] shadow-lg cursor-pointer"
                onClick={() => setSelectedItem(cake)}
              >
                {/* Image panel with zoom on hover */}
                <div className="w-full h-full overflow-hidden relative">
                  <img
                    src={cake.imageUrl}
                    alt={cake.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  {/* Subtle black mask that lightens on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent group-hover:from-black/90 transition-all duration-300" />
                </div>

                {/* Floating zoom indicator icon */}
                <div className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/70 border border-white/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Maximize2 className="w-4 h-4 text-brand-pink" />
                </div>

                {/* Cake Info Overlay (Bottom) */}
                <div className="absolute bottom-0 left-0 right-0 p-5 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 flex flex-col justify-end">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-brand-pink mb-1">
                    {cake.category}
                  </span>
                  <h3 className="font-serif font-bold text-lg text-white mb-1 group-hover:text-brand-pink transition-colors">
                    {cake.name}
                  </h3>
                  <p className="text-[11px] text-cream-200/60 line-clamp-1 group-hover:line-clamp-none transition-all duration-300">
                    {cake.description}
                  </p>
                  <span className="font-mono text-[9px] text-gold/60 mt-2 block opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    ID: {cake.sku}
                  </span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Fast facts metadata feedback strip */}
        <div className="mt-12 text-center text-xs font-mono text-cream-200/40">
          Showing {filteredCakes.length} out of 40 spectacular handcrafted designer cakes
        </div>

      </div>

      {/* LIGHTBOX IMMERSIVE MODAL PORTAL */}
      <SubLightBoxWrapper>
        <AnimatePresence>
          {selectedItem && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md"
            id="lightbox-backdrop"
          >
            {/* Direct Close touch-target mask */}
            <div className="absolute inset-0" onClick={() => setSelectedItem(null)} />

            {/* Custom Lightbox Card container */}
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              transition={{ type: "spring", damping: 25, stiffness: 350 }}
              className="relative w-full max-w-4xl bg-dark-card border border-brand-pink/20 rounded-3xl overflow-hidden shadow-2xl z-10 grid grid-cols-1 md:grid-cols-2"
              id="lightbox-card"
            >
              {/* Close Button Trigger */}
              <button
                id="lightbox-close-btn"
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/65 border border-white/10 flex items-center justify-center text-cream-100 hover:text-brand-pink cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left Column: Swipable Cake Photo Layout */}
              <div className="relative h-[300px] md:h-[500px] bg-zinc-950 overflow-hidden select-none">
                <img
                  src={selectedItem.imageUrl}
                  alt={selectedItem.name}
                  className="w-full. h-full w-full object-cover object-center"
                  referrerPolicy="no-referrer"
                />
                
                {/* Prev & Next Quick-Switch Controls */}
                <button
                  id="lightbox-prev-btn"
                  onClick={() => handlePrevItem(selectedItem.id)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 border border-white/5 hover:border-brand-pink/40 flex items-center justify-center text-cream-100 hover:text-brand-pink cursor-pointer"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  id="lightbox-next-btn"
                  onClick={() => handleNextItem(selectedItem.id)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 border border-white/5 hover:border-brand-pink/40 flex items-center justify-center text-cream-100 hover:text-brand-pink cursor-pointer"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Right Column: Full Details & WhatsApp Inquiry Actions */}
              <div className="p-8 flex flex-col justify-between bg-dark-card/95">
                <div className="space-y-6">
                  {/* Category and Icon badges */}
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-pink/10 border border-brand-pink/20 text-brand-pink text-[10px] uppercase font-mono font-bold tracking-wider">
                      <Sparkles className="w-3 h-3" />
                      {selectedItem.category}
                    </span>
                    <span className="text-xs font-mono text-zinc-400 uppercase">
                      Artisan Line
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white tracking-wide">
                    {selectedItem.name}
                  </h3>

                  {/* Divider */}
                  <div className="h-[1px] w-full bg-brand-pink/10" />

                  {/* Description */}
                  <div>
                    <h4 className="font-mono text-[10px] text-gold uppercase tracking-widest font-bold mb-2">Description</h4>
                    <p className="text-sm text-cream-200/90 leading-relaxed">
                      {selectedItem.description}
                    </p>
                  </div>

                  {/* Unique SKU / ID Card */}
                  <div className="p-3.5 rounded-xl bg-zinc-950/60 border border-zinc-900 flex items-center justify-between font-mono">
                    <div>
                      <p className="text-[10px] text-zinc-400 uppercase tracking-widest">PRODUCT SKU</p>
                      <p className="text-xs text-white uppercase mt-0.5 font-bold">{selectedItem.sku}</p>
                    </div>
                    <button
                      onClick={() => handleCopySKU(selectedItem.sku)}
                      className="p-2 rounded-lg hover:bg-zinc-900 border border-transparent hover:border-zinc-800 text-zinc-400 hover:text-brand-pink cursor-pointer transition-colors"
                      title="Copy SKU Code"
                    >
                      {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Order Link Inquiry via WhatsApp */}
                <div className="mt-8 pt-6 border-t border-brand-pink/10">
                  <a
                    id="lightbox-whatsapp-inquiry-btn"
                    href={`https://wa.me/918016234702?text=Hi%20Shankar%20Bakers%2C%20I'm%20very%20interested%20in%20inquiring%20about%20ordering%20the%20custom%20cake%3A%20${encodeURIComponent(
                      selectedItem.name
                    )}%20(SKU%3A%20${selectedItem.sku}).%20Could%20you%20please%20provide%20pricing%20details%20for%20a%201kg/2kg%20size%3F`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-4.5 rounded-full bg-brand-pink text-dark-obsidian hover:bg-[#25D366] hover:text-white font-bold text-sm tracking-widest uppercase transition-colors duration-300 flex items-center justify-center gap-2 group shadow-lg shadow-brand-pink/10"
                  >
                    <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    <span>Inquire via WhatsApp</span>
                  </a>
                  <p className="text-[10px] text-center text-zinc-400 mt-3 font-medium">
                    📍 Baking Freshly in siliguri • Bespoke weights from 500g to 10kg
                  </p>
                </div>
              </div>

            </motion.div>
          </motion.div>
        )}
        </AnimatePresence>
      </SubLightBoxWrapper>
    </section>
  );
}

// Minimal Portal style clean alignment container for code uniformity
function SubLightBoxWrapper({ children }: { children: ReactNode }) {
  return <div id="lightbox-portal">{children}</div>;
}
