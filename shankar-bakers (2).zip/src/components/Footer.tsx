import { Cake, Instagram, Facebook, MessageCircle, Heart, ArrowUp } from "lucide-react";

export default function Footer() {
  const quickLinks = [
    { name: "Home", href: "#home" },
    { name: "About Us", href: "#about" },
    { name: "Gallery", href: "#gallery" },
    { name: "Menu", href: "#menu" },
    { name: "Reviews", href: "#reviews" },
    { name: "Contact Us", href: "#contact" },
  ];

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer id="footer" className="bg-dark-obsidian border-t border-white/5 pt-16 pb-12 px-6 relative overflow-hidden">
      
      {/* Footer grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-12 pb-12 border-b border-white/5 relative z-10">
        
        {/* Left Column: Brand name description */}
        <div className="md:col-span-5 space-y-6">
          <a href="#home" className="flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-full bg-brand-pink/15 flex items-center justify-center border border-brand-pink/25">
              <Cake className="w-5 h-5 text-brand-pink" />
            </div>
            <div>
              <span className="font-serif text-lg font-bold tracking-wide block leading-none text-white">
                Shankar <span className="text-brand-pink text-shimmer">Bakers</span>
              </span>
              <span className="font-mono text-[8px] uppercase tracking-widest text-gold block mt-1">
                Siliguri's Finest Confectionery
              </span>
            </div>
          </a>
          
          <p className="text-xs text-cream-205/60 leading-relaxed max-w-sm text-left">
            An elite confectionery parlor based in Siliguri, dedicated to turning your sweet dreams into gourmet sculptural realities. We bake 100% pure, hygienic, and fresh luxury cakes with premium Belgian chocolate and organic layers.
          </p>

          {/* Social icons row */}
          <div className="flex items-center gap-3">
            <a
              id="footer-ig"
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-zinc-950 hover:bg-brand-pink border border-zinc-900 text-cream-300 hover:text-dark-obsidian flex items-center justify-center transition-all duration-300 transform hover:-translate-y-1"
            >
              <Instagram className="w-4.5 h-4.5" />
            </a>
            
            <a
              id="footer-wa"
              href="https://wa.me/918016234702"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-zinc-950 hover:bg-emerald-500 border border-zinc-900 text-cream-300 hover:text-white flex items-center justify-center transition-all duration-300 transform hover:-translate-y-1"
            >
              <MessageCircle className="w-4.5 h-4.5" />
            </a>

            <a
              id="footer-fb"
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-zinc-950 hover:bg-blue-500 border border-zinc-900 text-cream-300 hover:text-white flex items-center justify-center transition-all duration-300 transform hover:-translate-y-1"
            >
              <Facebook className="w-4.5 h-4.5" />
            </a>
          </div>
        </div>

        {/* Center-Right Columns: Quick Navigation */}
        <div className="md:col-span-3 space-y-4">
          <h4 className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold">Quick Navigation</h4>
          <ul className="space-y-2.5 text-left text-xs">
            {quickLinks.map((link) => (
              <li key={link.name}>
                <a
                  href={link.href}
                  className="text-cream-205/70 hover:text-brand-pink transition-colors"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Right Column: Mini Contact and location reference */}
        <div className="md:col-span-4 space-y-4 text-left">
          <h4 className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold">Inquiries & Landmarks</h4>
          <ul className="space-y-3 text-xs text-cream-205/70">
            <li>
              <span className="block text-zinc-500 font-mono text-[9px] uppercase">Main Store Address</span>
              <p className="mt-0.5 leading-relaxed">
                Jhankar More, Vivekananda Road, Mahananda Para,<br />
                Siliguri, West Bengal
              </p>
            </li>
            <li>
              <span className="block text-zinc-500 font-mono text-[9px] uppercase">Phone Line</span>
              <a href="tel:08016234702" className="text-gold font-bold hover:underline font-mono">08016234702</a>
            </li>
          </ul>
        </div>

      </div>

      {/* Copyright branding row and smooth-scroll-top */}
      <div className="max-w-7xl mx-auto pt-8 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10 font-sans text-[11px] text-zinc-500">
        
        {/* Left: Copyright */}
        <p className="order-2 md:order-1">
          &copy; 2025 Shankar Bakers. All Rights Reserved.
        </p>

        {/* Center: Made with love message */}
        <p className="order-1 md:order-2 inline-flex items-center gap-1 text-zinc-400 font-medium">
          Made with <Heart className="w-3 h-3 text-brand-pink fill-current animate-pulse" /> by Shankar Bakers
        </p>

        {/* Right: Scroll Top Button */}
        <button
          id="footer-scroll-top-btn"
          onClick={handleScrollTop}
          className="order-3 p-2.5 rounded-full bg-zinc-950 border border-zinc-900 text-cream-300 hover:text-brand-pink hover:border-brand-pink/30 cursor-pointer transition-all duration-300"
          title="Scroll to Top"
        >
          <ArrowUp className="w-4 h-4" />
        </button>

      </div>
      
    </footer>
  );
}
