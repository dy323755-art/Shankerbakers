import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MENU_CAKES, MenuItem } from "../data";
import { MessageCircle, Star, Sparkles, Filter, Leaf } from "lucide-react";

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState<string>("All Menu");

  const menuCategories = [
    "All Menu",
    "Chocolate Cakes",
    "Vanilla Cakes",
    "Fruit Cakes",
    "Designer Cakes",
    "Cupcakes",
  ];

  // Filter menu items dynamically
  const filteredMenu = activeCategory === "All Menu"
    ? MENU_CAKES
    : MENU_CAKES.filter((item) => item.category === activeCategory);

  return (
    <section id="menu" className="py-24 px-6 relative bg-zinc-950/40">
      {/* Background soft lighting */}
      <div className="absolute top-1/4 right-0 w-80 h-80 bg-gold/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-brand-pink/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        
        {/* Title Group */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
            GOURMET MENU
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-6">
            Explore Our Sweet Offerings
          </h2>
          <p className="text-sm md:text-base text-cream-200/80 leading-relaxed">
            Every item in our menu is baked raw from high-quality components, highlighting genuine cacao fat, free from unhealthy hydrogenated vegetable oils. Suitable for both celebratory parties and casual cravings.
          </p>
        </div>

        {/* Menu category sliding tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-16 max-w-4xl mx-auto">
          {menuCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-xs font-mono tracking-wider transition-all duration-300 pointer-events-auto cursor-pointer focus:outline-none ${
                activeCategory === cat
                  ? "bg-gold text-dark-obsidian font-bold shadow-md shadow-gold/20"
                  : "bg-dark-card border border-white/5 text-cream-300 hover:text-gold hover:border-gold/30 hover:bg-zinc-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Dynamic Menu Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredMenu.map((item, idx) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                key={item.id}
                id={`menu-card-${item.id}`}
                className="group rounded-2xl overflow-hidden bg-dark-card border border-white/5 hover:border-gold/20 transition-all duration-300 flex flex-col justify-between shadow-xl shadow-black/80"
              >
                {/* Image Section */}
                <div className="relative h-[220px] overflow-hidden bg-zinc-950">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                  />
                  {/* Draped shadow overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  {/* Category Stamp label (Top-Left) */}
                  <span className="absolute top-4 left-4 inline-block px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md border border-white/10 text-[9px] font-mono font-semibold text-zinc-300 uppercase tracking-widest">
                    {item.category}
                  </span>

                  {/* Dynamic Badge Labels (Top-Right) */}
                  {item.badge && (
                    <span className={`absolute top-4 right-4 inline-flex items-center gap-1 px-3 py-1 rounded-md text-[9px] font-mono uppercase tracking-widest font-extrabold ${
                      item.badge === "Best Seller"
                        ? "bg-brand-pink text-dark-obsidian shadow-sm shadow-brand-pink/20"
                        : item.badge === "Chef Special"
                        ? "bg-gold text-dark-obsidian shadow-sm shadow-gold/20"
                        : item.badge === "Eggless"
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                    }`}>
                      {item.badge === "Eggless" && <Leaf className="w-2.5 h-2.5" />}
                      <span>{item.badge}</span>
                    </span>
                  )}
                </div>

                {/* Info and Purchase section */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Stars and ID Row */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1 text-gold">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span className="text-xs font-mono font-bold text-cream-100">{item.rating.toFixed(1)}</span>
                      </div>
                      <span className="text-[9px] font-mono text-zinc-500">KITCHEN CODE #{item.id.toUpperCase()}</span>
                    </div>

                    {/* Cake Title */}
                    <h3 className="font-serif font-bold text-xl text-white mb-2 group-hover:text-gold transition-colors">
                      {item.name}
                    </h3>

                    {/* Short description */}
                    <p className="text-xs text-cream-250/70 leading-relaxed mb-4 line-clamp-2">
                      {item.description}
                    </p>
                  </div>

                  {/* Price and Transaction Button Block */}
                  <div className="pt-4 border-t border-white/5 flex items-center justify-between mt-auto">
                    <div>
                      <span className="font-mono text-[9px] text-zinc-400 block uppercase tracking-widest">Starting at</span>
                      <span className="text-xl font-serif font-bold text-gold">₹{item.price.toLocaleString("en-IN")}</span>
                    </div>

                    <a
                      id={`menu-order-btn-${item.id}`}
                      href={`https://wa.me/918016234702?text=Hi%20Shankar%20Bakers%2C%20I'd%20like%20to%20order%20the%20${encodeURIComponent(
                        item.name
                      )}%20(Starting%20at%20₹${item.price.toLocaleString("en-IN")})%20from%20your%2520Gourmet%2520Menu.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4.5 py-2.5 rounded-full bg-zinc-900 border border-zinc-800 text-cream-100 group-hover:bg-gold group-hover:text-dark-obsidian group-hover:border-gold hover:scale-105 transition-all duration-300 font-bold text-xs flex items-center gap-1.5"
                    >
                      <MessageCircle className="w-4 h-4 shrink-0" />
                      <span>Order on WA</span>
                    </a>
                  </div>
                </div>

              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Special guidance banner card */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-r from-zinc-950 via-dark-card to-zinc-950 border border-gold/10 text-center max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="text-left md:max-w-xl">
            <h4 className="font-serif font-bold text-xl text-white mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-gold" />
              Looking for a custom designer masterpiece?
            </h4>
            <p className="text-xs text-cream-200/70 leading-relaxed">
              We specialize in custom layered birthday templates, elegant corporate sets, multi-tier fondant decorations, and vegan/sugar-free dessert custom requests. Share your blueprint design sketches with us!
            </p>
          </div>
          <a
            href="#contact"
            className="px-6 py-3 rounded-full bg-gold hover:bg-gold/90 text-dark-obsidian font-bold text-xs tracking-wider uppercase shrink-0 transition-transform hover:scale-105"
          >
            Design Custom Cake
          </a>
        </div>

      </div>
    </section>
  );
}
