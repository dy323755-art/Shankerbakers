import { useState, useEffect } from "react";
import { Menu, X, Cake, Phone, MessageCircle, Instagram, Facebook } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface NavbarProps {
  onContactClick: () => void;
}

export default function Navbar({ onContactClick }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "About Us", href: "#about" },
    { name: "Gallery", href: "#gallery" },
    { name: "Menu", href: "#menu" },
    { name: "Reviews", href: "#reviews" },
    { name: "Contact", href: "#contact" },
  ];

  return (
    <>
      <nav
        id="main-navbar"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? "bg-dark-obsidian/90 backdrop-blur-md border-b border-brand-pink/10 py-4 shadow-lg shadow-black/40"
            : "bg-transparent py-6"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <a
            id="nav-logo"
            href="#home"
            className="flex items-center gap-3 group"
          >
            <div className="w-10 h-10 rounded-full bg-brand-pink/20 flex items-center justify-center border border-brand-pink/30 group-hover:scale-110 transition-transform duration-300">
              <Cake className="w-6 h-6 text-brand-pink" />
            </div>
            <div>
              <span className="font-serif text-xl md:text-2xl font-bold tracking-wide block leading-none">
                Shankar <span className="text-brand-pink text-shimmer">Bakers</span>
              </span>
              <span className="font-mono text-[9px] uppercase tracking-widest text-gold block mt-1">
                Siliguri's Finest Desserts
              </span>
            </div>
          </a>

          {/* Desktop Navigation Link Items */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                id={`nav-link-${link.name.toLowerCase().replace(" ", "-")}`}
                href={link.href}
                className="text-cream-100 hover:text-brand-pink text-sm uppercase tracking-wider font-medium transition-colors duration-300 relative group py-2"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-pink transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* Contact Buttons & Mobile Toggle */}
          <div className="hidden md:flex items-center gap-4">
            <a
              id="nav-social-ig"
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cream-300 hover:text-brand-pink transition-colors duration-300"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a
              id="nav-social-fb"
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cream-300 hover:text-brand-pink transition-colors duration-300"
            >
              <Facebook className="w-5 h-5" />
            </a>
            <button
              id="nav-contact-btn"
              onClick={onContactClick}
              className="px-5 py-2.5 rounded-full bg-cream-100 text-dark-obsidian hover:bg-brand-pink hover:text-dark-obsidian font-semibold text-sm transition-all duration-300 flex items-center gap-2 group cursor-pointer focus:outline-none"
            >
              <Phone className="w-4 h-4 group-hover:rotate-12 transition-transform" />
              <span>Contact Us</span>
            </button>
          </div>

          {/* Mobile Menu Icon */}
          <div className="md:hidden flex items-center gap-4">
            <button
              id="mobile-contact-shortcut"
              onClick={onContactClick}
              className="w-9 h-9 rounded-full bg-brand-pink/20 flex items-center justify-center border border-brand-pink/30 text-brand-pink cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
            </button>
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-cream-100 hover:text-brand-pink p-1 cursor-pointer focus:outline-none"
            >
              {isMobileMenuOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-menu-drawer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed top-[73px] left-0 right-0 z-40 bg-dark-card border-b border-brand-pink/10 shadow-2xl block md:hidden"
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  id={`mobile-nav-link-${link.name.toLowerCase().replace(" ", "-")}`}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-cream-100 hover:text-brand-pink text-base uppercase tracking-wider font-semibold py-1 border-b border-white/5"
                >
                  {link.name}
                </a>
              ))}
              <div className="flex items-center justify-between pt-4 mt-2">
                <div className="flex gap-4">
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-cream-300 hover:text-brand-pink"
                    rel="noreferrer"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-cream-300 hover:text-brand-pink"
                    rel="noreferrer"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                </div>
                <button
                  id="mobile-drawer-contact-btn"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onContactClick();
                  }}
                  className="px-6 py-3 rounded-full bg-brand-pink text-dark-obsidian font-bold text-sm tracking-wide flex items-center gap-2 cursor-pointer"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call Us Now</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
