import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MapPin, Phone, MessageCircle, Clock, Send, CheckCircle2, ChevronRight, Loader2 } from "lucide-react";

export default function Contact() {
  const [formState, setFormState] = useState({
    name: "",
    phone: "",
    eventType: "Birthday",
    cakeWeight: "1 kg",
    date: "",
    instructions: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    // Minimal validation
    if (!formState.name.trim() || !formState.phone.trim()) {
      setErrorMessage("Please fill in your name and telephone number so we can reach back.");
      return;
    }

    setIsSubmitting(true);

    // Simulate luxury API response lag
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      // Reset form
      setFormState({
        name: "",
        phone: "",
        eventType: "Birthday",
        cakeWeight: "1 kg",
        date: "",
        instructions: "",
      });
    }, 1800);
  };

  return (
    <section id="contact" className="py-24 px-6 relative bg-dark-obsidian">
      {/* Decorative colored glow spheres */}
      <div className="absolute top-1/3 left-1/4 -translate-y-1/2 w-96 h-96 bg-brand-pink/5 blur-[140px] pointer-events-none" />
      <div className="absolute top-2/3 right-1/4 -translate-y-1/2 w-96 h-96 bg-gold/5 blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Title details */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
            GET IN TOUCH
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-6">
            Bespoke Baking Consultations
          </h2>
          <p className="text-sm md:text-base text-cream-205/80 leading-relaxed">
            Have questions about pricing, weights, delivery ranges, or customization? Send us an inquiry or speak directly across instant channels.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mt-8">
          
          {/* LEFT 5 COLUMNS: Contact details card cluster */}
          <div className="lg:col-span-5 space-y-6">
            
            <h3 className="font-serif text-2xl font-bold text-white mb-4">
              Contact Details
            </h3>

            {/* Address Card */}
            <div className="p-6 rounded-2xl bg-dark-card border border-white/5 hover:border-brand-pink/20 transition-colors duration-300 shadow-xl flex gap-4">
              <div className="w-11 h-11 rounded-xl bg-zinc-950 border border-brand-pink/10 flex items-center justify-center text-brand-pink shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="text-left font-sans">
                <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-400">Our Bakery Location</span>
                <h4 className="font-semibold text-white mt-1 text-base">Jhankar More</h4>
                <p className="text-xs text-cream-205/70 mt-1 leading-relaxed">
                  Vivekananda Road, Ward 4, Mahananda Para,<br />
                  Siliguri, West Bengal - 734001
                </p>
                <a
                  href="https://maps.google.com/?q=Jhankar+More+Vivekananda+Road+Siliguri"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs text-brand-pink mt-3 font-semibold hover:underline"
                >
                  <span>Open in Google Maps</span>
                  <ChevronRight className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Phone Card */}
            <div className="p-6 rounded-2xl bg-dark-card border border-white/5 hover:border-gold/20 transition-colors duration-300 shadow-xl flex gap-4">
              <div className="w-11 h-11 rounded-xl bg-zinc-950 border border-gold/10 flex items-center justify-center text-gold shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-left font-sans">
                <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-400">Direct Telephone Dial</span>
                <h4 className="font-semibold text-white mt-1 text-base">Speak to Our Head Baker</h4>
                <a
                  href="tel:08016234702"
                  className="font-mono text-lg font-bold text-gold mt-1 block hover:underline"
                >
                  08016234702
                </a>
                <p className="text-[10px] text-zinc-500 mt-1">Available for quick calls daily 9 AM - 9 PM</p>
              </div>
            </div>

            {/* Hourly details card */}
            <div className="p-6 rounded-2xl bg-dark-card border border-white/5 shadow-xl flex gap-4">
              <div className="w-11 h-11 rounded-xl bg-zinc-950 border border-white/5 flex items-center justify-center text-zinc-400 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div className="text-left font-sans">
                <span className="text-[10px] uppercase font-mono tracking-wider text-zinc-400">Baking & Pickup Hours</span>
                <h4 className="font-semibold text-white mt-1 text-base">Fresh Daily Batches</h4>
                <p className="text-xs text-cream-205/70 mt-1">
                  Monday – Sunday: <strong className="text-white">8:00 AM – 10:00 PM</strong>
                </p>
                <p className="text-[10px] text-zinc-500 mt-1">Orders for custom/wedding cakes require 24-48 hours lead time.</p>
              </div>
            </div>

            {/* Primary Action: High-Contrast Premium Callout */}
            <div className="p-6 rounded-3xl bg-white text-black border border-white/10 shadow-2xl flex flex-col justify-between gap-6 hover:scale-[1.02] transition-transform duration-300">
              <div>
                <h4 className="font-mono text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                  Contact Info & Landmarks
                </h4>
                <p className="text-sm font-medium text-zinc-900 leading-relaxed md:text-base">
                  Jhankar More, Vivekananda Road,<br />
                  Ward 4, Mahananda Para, Siliguri
                </p>
                <a
                  href="tel:08016234702"
                  className="text-2xl font-serif mt-3 font-bold italic text-black block hover:underline"
                >
                  08016234702
                </a>
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-black/10 mt-2">
                <div className="flex gap-2.5">
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-full bg-black/10 hover:bg-brand-pink text-black flex items-center justify-center text-[10px] font-bold transition-all duration-300 hover:scale-105"
                  >
                    IG
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-full bg-black/10 hover:bg-blue-500 hover:text-white text-black flex items-center justify-center text-[10px] font-bold transition-all duration-300 hover:scale-105"
                  >
                    FB
                  </a>
                  <a
                    href="https://wa.me/918016234702"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-7 h-7 rounded-full bg-black/10 hover:bg-emerald-500 hover:text-white text-black flex items-center justify-center text-[10px] font-bold transition-all duration-300 hover:scale-105"
                  >
                    WA
                  </a>
                </div>
                <span className="text-[10px] uppercase font-bold text-zinc-400">© 2025 Shankar Bakers</span>
              </div>
            </div>

          </div>

          {/* RIGHT 7 COLUMNS: Consultation/Order Booking Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-8 md:p-10 rounded-3xl bg-dark-card border border-white/5 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-pink/5 blur-[50px] pointer-events-none" />

              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.form
                    key="consultation-form"
                    onSubmit={handleSubmit}
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-6"
                  >
                    <div>
                      <h3 className="font-serif text-2xl font-bold text-white mb-1">
                        Bespoke Consultation
                      </h3>
                      <p className="text-xs text-cream-205/60">
                        Leave your requirements here and our confectionary specialist will contact you.
                      </p>
                    </div>

                    {/* Validation warning */}
                    {errorMessage && (
                      <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/25 text-red-300 text-xs text-left font-medium">
                        {errorMessage}
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      {/* Name input */}
                      <div className="flex flex-col text-left">
                        <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                          Your Name *
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={formState.name}
                          onChange={handleInputChange}
                          placeholder="What should we call you?"
                          className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors"
                          required
                        />
                      </div>

                      {/* Phone input */}
                      <div className="flex flex-col text-left">
                        <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                          Contact Number *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={formState.phone}
                          onChange={handleInputChange}
                          placeholder="Your calling/WhatsApp number"
                          className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors font-mono"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      {/* Event Type select */}
                      <div className="flex flex-col text-left">
                        <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                          Occasions Layer
                        </label>
                        <select
                          name="eventType"
                          value={formState.eventType}
                          onChange={handleInputChange}
                          className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors cursor-pointer"
                        >
                          <option value="Birthday">Birthday Celebrating</option>
                          <option value="Wedding">Wedding Landmarks</option>
                          <option value="Anniversary">Anniversary Milestones</option>
                          <option value="Corporate">Corporate / Custom Gift</option>
                          <option value="Other">Other Gourmet Desires</option>
                        </select>
                      </div>

                      {/* Weight Selector */}
                      <div className="flex flex-col text-left">
                        <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                          Preferred Size/Weight
                        </label>
                        <select
                          name="cakeWeight"
                          value={formState.cakeWeight}
                          onChange={handleInputChange}
                          className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors cursor-pointer"
                        >
                          <option value="500 grams">500 grams (Standard Small)</option>
                          <option value="1 kg">1 kg (Medium Family size)</option>
                          <option value="2 kg">2 kg (Large celebration)</option>
                          <option value="3 kg+">3 kg+ (Grand Landmark)</option>
                          <option value="Assorted Cupcakes">Cupcake box (6 / 12 pieces)</option>
                        </select>
                      </div>
                    </div>

                    {/* Date */}
                    <div className="flex flex-col text-left">
                      <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                        Desired Delivery / Pickup Date
                      </label>
                      <input
                        type="date"
                        name="date"
                        value={formState.date}
                        onChange={handleInputChange}
                        className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors cursor-pointer font-mono"
                      />
                    </div>

                    {/* Specifications */}
                    <div className="flex flex-col text-left">
                      <label className="font-mono text-[10px] text-zinc-400 uppercase tracking-widest font-bold mb-2">
                        Special Instructions
                      </label>
                      <textarea
                        name="instructions"
                        value={formState.instructions}
                        onChange={handleInputChange}
                        placeholder="E.g., eggless option, write 'Happy Birthday Priya', pastel rose petals design, low-sugar request."
                        rows={3}
                        className="px-4.5 py-3.5 rounded-xl bg-zinc-950 border border-zinc-900 focus:border-brand-pink/50 text-white text-sm outline-none transition-colors resize-none"
                      />
                    </div>

                    {/* Submit action */}
                    <button
                      id="contact-form-submit-btn"
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 rounded-xl bg-brand-pink text-dark-obsidian font-bold tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:bg-brand-pink-light disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span>Validating Credentials...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Submit Custom Request</span>
                        </>
                      )}
                    </button>
                  </motion.form>
                ) : (
                  // Success layout component
                  <motion.div
                    key="consultation-success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="py-12 text-center"
                    id="contact-form-success"
                  >
                    <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-6">
                      <CheckCircle2 className="w-9 h-9" />
                    </div>
                    <h3 className="font-serif text-3xl font-bold text-white mb-3">
                      Inquiry Received!
                    </h3>
                    <p className="text-sm text-cream-205/85 max-w-md mx-auto leading-relaxed mb-8">
                      Thank you! Your custom cake design instructions have been successfully registered under our baking roster. Our chef will connect with you via call or WhatsApp within 15 minutes!
                    </p>
                    <button
                      id="contact-form-reset-btn"
                      onClick={() => setIsSubmitted(false)}
                      className="px-6 py-2.5 rounded-full bg-zinc-950 border border-zinc-900 text-cream-300 hover:text-brand-pink hover:border-brand-pink/30 text-xs font-semibold uppercase tracking-wider cursor-pointer"
                    >
                      Send Another Request
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
