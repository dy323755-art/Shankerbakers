import { motion } from "motion/react";
import { Check, ShieldCheck, Heart, Sparkles, Clock, Utensils } from "lucide-react";

export default function About() {
  const highlights = [
    {
      icon: <Utensils className="w-5 h-5 text-brand-pink" />,
      title: "Fresh Ingredients",
      desc: "Only premium organic butter, gourmet Belgian cocoa, and handpicked seasonal fruits are allowed in our kitchen.",
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-gold" />,
      title: "Hygienic Preparation",
      desc: "Sterilized high-end gourmet kitchen environment adhering strictly to elite certified health practices.",
    },
    {
      icon: <Sparkles className="w-5 h-5 text-brand-pink" />,
      title: "Custom Cake Designs",
      desc: "Expert pastry artists turning your dreams, sketch designs, or branding ideas into edible sculptural luxury.",
    },
    {
      icon: <Clock className="w-5 h-5 text-gold" />,
      title: "Fast & Safe Delivery",
      desc: "Meticulous temperature-controlled transit ensuring your delicate custom creations arrive intact.",
    },
    {
      icon: <Heart className="w-5 h-5 text-brand-pink fill-current" />,
      title: "Premium Quality Taste",
      desc: "Perfect sugar-to-cream ratio, resulting in a rich, velvety, not-too-sweet mouthfeel.",
    },
  ];

  return (
    <section id="about" className="py-24 px-6 relative bg-zinc-950/40">
      {/* Decorative subtle geometric background borders */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-pink/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gold/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Leftside: Immersive Story Telling Imagery with layered borders */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            {/* Visual offset glowing frame */}
            <div className="absolute -inset-4 rounded-3xl border border-brand-pink/20 scale-95 md:scale-100 translate-x-3 translate-y-3 pointer-events-none" />
            
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] sm:aspect-square shadow-2xl shadow-black/80">
              <img
                src="/src/assets/images/regenerated_image_1780067034979.jpg"
                alt="Shankar Bakers Chef baking fresh premium delicacies"
                className="w-full h-full object-cover filter brightness-95 hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              {/* Image dark corner shaders */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
              
              {/* Floating review count tag */}
              <div className="absolute bottom-6 left-6 p-4 rounded-xl bg-dark-obsidian/95 backdrop-blur-md border border-gold/20 flex items-center gap-3">
                <span className="text-3xl font-serif font-bold text-gold">10+</span>
                <div>
                  <p className="text-xs font-bold text-white uppercase tracking-wider">Years of Artisan Excellence</p>
                  <p className="text-[10px] text-zinc-400">Siliguri, West Bengal</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Rightside: Content & Key Highlights with premium card templates */}
          <div>
            {/* Minimal marker label */}
            <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
              ABOUT SHANKAR BAKERS
            </span>

            <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-6 leading-tight">
              Crafting Divine Sweet Moments In Siliguri
            </h2>

            <p className="text-cream-200 text-sm md:text-base leading-relaxed mb-8">
              At <strong className="text-brand-pink font-semibold">Shankar Bakers</strong>, baking isn’t just a checklist; it's a profound, artistic craft. From our humble beginnings in Siliguri, we have set a golden benchmark for confectionary luxury. We merge traditional slow-baking techniques with modern artistic designs to produce premium custom birthday, celebration, and landmark wedding cakes.
            </p>

            {/* Structured Card Grid list */}
            <div className="flex flex-col gap-4">
              {highlights.map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  id={`about-card-${index}`}
                  className="p-5 rounded-xl bg-dark-card/60 hover:bg-dark-card border border-white/5 hover:border-brand-pink/20 transition-all duration-300 flex gap-4 items-start shadow-xs shadow-black"
                >
                  <div className="w-10 h-10 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-lg text-cream-100 mb-1 flex items-center gap-2">
                      {item.title}
                      {index === 4 && <span className="inline-block text-xs uppercase px-2 py-0.5 rounded-full bg-brand-pink/15 text-brand-pink font-mono scale-90">Core Focus</span>}
                    </h4>
                    <p className="text-xs text-cream-200/70 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
