import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { REVIEWS } from "../data";
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react";

export default function Reviews() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto sliding carousel interval
  useEffect(() => {
    if (!isHovered) {
      timerRef.current = setInterval(() => {
        handleNext();
      }, 5500);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeIndex, isHovered]);

  const handleNext = () => {
    setActiveIndex((prev) => (prev < REVIEWS.length - 1 ? prev + 1 : 0));
  };

  const handlePrev = () => {
    setActiveIndex((prev) => (prev > 0 ? prev - 1 : REVIEWS.length - 1));
  };

  return (
    <section id="reviews" className="py-24 px-6 relative bg-dark-obsidian overflow-hidden">
      {/* Background ambient circular glow lights */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-brand-pink/5 blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-gold/5 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto position-relative z-10">
        
        {/* Title Block with Google Badge branding */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="font-mono text-xs text-brand-pink tracking-widest uppercase font-semibold block mb-3">
            CUSTOMER VOICE
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-bold tracking-tight text-white mb-6">
            Words From Our Sweet Lovers
          </h2>
          
          {/* Mock Real Google Rating Badge */}
          <div className="inline-flex items-center gap-3 px-4 py-2 rounded-xl bg-zinc-950 border border-zinc-900 shadow-sm mt-2">
            {/* Google Logo Representation */}
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            <div className="text-left font-sans">
              <div className="flex items-center gap-1.5 leading-none">
                <span className="text-sm font-bold text-white">4.9/5</span>
                <div className="flex text-amber-400">
                  <Star className="w-3 h-3 fill-current" />
                  <Star className="w-3 h-3 fill-current" />
                  <Star className="w-3 h-3 fill-current" />
                  <Star className="w-3 h-3 fill-current" />
                  <Star className="w-3 h-3 fill-current" />
                </div>
              </div>
              <p className="text-[10px] text-zinc-400 mt-0.5 font-medium">based on 1,420+ Siliguri local reviews</p>
            </div>
          </div>
        </div>

        {/* Sliding Testimonial Main Container */}
        <div
          id="testimonial-carousel-wrap"
          className="relative max-w-4xl mx-auto px-12"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Main Card */}
          <div className="relative rounded-3xl bg-dark-card border border-brand-pink/10 shadow-2xl p-8 sm:p-12 md:p-16 overflow-hidden min-h-[320px] flex flex-col justify-between">
            {/* Quote watermark background */}
            <Quote className="absolute top-8 right-8 w-24 h-24 text-brand-pink/5 stroke-[1.5] pointer-events-none" />

            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
                className="space-y-8 flex-1 flex flex-col justify-between"
              >
                {/* Review Body Text */}
                <p className="font-serif italic text-base sm:text-xl md:text-2xl text-cream-100/95 leading-relaxed font-light">
                  “{REVIEWS[activeIndex].text}”
                </p>

                {/* Customer footer row */}
                <div className="flex items-center justify-between gap-4 pt-6 border-t border-white/5 mt-auto">
                  <div className="flex items-center gap-4">
                    {/* Rounded avatar frame */}
                    <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-brand-pink/30 flex-shrink-0 bg-zinc-900">
                      <img
                        src={REVIEWS[activeIndex].avatarUrl}
                        alt={REVIEWS[activeIndex].name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="font-sans font-bold text-sm sm:text-base text-white">{REVIEWS[activeIndex].name}</h4>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] font-mono text-gold uppercase tracking-wider">{REVIEWS[activeIndex].role}</span>
                        <span className="text-[10px] text-zinc-500">•</span>
                        <span className="text-[10px] text-zinc-500">{REVIEWS[activeIndex].date}</span>
                      </div>
                    </div>
                  </div>

                  {/* 5-Stars Highlight */}
                  <div className="flex gap-1 text-gold">
                    {Array.from({ length: REVIEWS[activeIndex].rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current text-gold" />
                    ))}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Left / Right Navigation Manual Buttons */}
          <button
            id="review-prev-btn"
            onClick={handlePrev}
            className="absolute -left-2 sm:left-0 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-dark-card border border-white/5 hover:border-brand-pink/50 flex items-center justify-center text-cream-200 hover:text-brand-pink cursor-pointer transition-all duration-300 shadow-lg"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          
          <button
            id="review-next-btn"
            onClick={handleNext}
            className="absolute -right-2 sm:right-0 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-dark-card border border-white/5 hover:border-brand-pink/50 flex items-center justify-center text-cream-200 hover:text-brand-pink cursor-pointer transition-all duration-300 shadow-lg"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Carousel indicators dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {REVIEWS.map((_, idx) => (
            <button
              key={idx}
              id={`review-indicator-${idx}`}
              onClick={() => setActiveIndex(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                activeIndex === idx ? "bg-brand-pink w-6" : "bg-zinc-800 hover:bg-zinc-700"
              }`}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
